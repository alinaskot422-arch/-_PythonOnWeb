import math

print("Решение квадратного уравнения")
print("ax² + bx + c = 0")
a = float(input("Введите a: "))
b = float(input("Введите b: "))
c = float(input("Введите c: "))
D = b*b - 4*a*c
print(f"Дискриминант D = {D}")

if D > 0:
    x1 = (-b + math.sqrt(D)) / (2*a)
    x2 = (-b - math.sqrt(D)) / (2*a)
    print(f"x1 = {x1}, x2 = {x2}")
elif D == 0:
    x = -b / (2*a)
    print(f"x = {x}")
else:
    print("Уравнение не имеет корней")