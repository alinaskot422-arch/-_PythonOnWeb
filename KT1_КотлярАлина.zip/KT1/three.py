print("Введите числа, а для окончания введите 100")
sum = 0
count = 0
while True:
    num = int(input("Введи число: "))
    if num == 100:
        break
    if num % 2 == 0:  
        sum = sum + num
        count = count + 1
if count > 0:
    an = sum / count
    print(f"Найдено {count} четных чисел")
    print(f"Их сумма: {sum}")
    print(f"Среднее арифметическое: {an}")
else:
    print("Четных чисел не нашли")