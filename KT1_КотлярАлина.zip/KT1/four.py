print("Введи слова через пробел:")
text = input()
words = text.split()
agree = True
for word in words:
    first = word[0]  
    if first == 'A' or first == 'a' or \
       first == 'B' or first == 'b' or \
       first == 'C' or first == 'c':
        continue 
    else:
        agree = False
        break
if agree:
    print("YES")
else:
    print("NO")