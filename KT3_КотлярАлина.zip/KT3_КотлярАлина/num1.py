def print_hello(name):
    print("Привет, " + name + "!")
string = input("Введите ваше имя ")
print_hello(string)
