n = int(input("Введите количество элементов массива: "))
arr = []
print("Введите элементы массива:")

for i in range(n):
    a = int(input(f"Элемент {i+1}: "))
    arr.append(a)

zeros = False

for i in range(len(arr) - 1):
    if arr[i] == 0 and arr[i+1] == 0:
        zeros = True
        break
print("Массив:", arr)

if zeros:
    print("В массиве есть два подряд идущих нуля")
else:
    print("В массиве нет двух подряд идущих нулей")
