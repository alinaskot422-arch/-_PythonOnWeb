import random

n = int(input("Введите количество элементов массива: "))
arr = []

for i in range(n):
    num = random.randint(1, 10)  
    arr.append(num) 
print("Массив:", arr)

count = 0
for num in arr:           
    if num % 3 == 0:    
        count += 1 

even = []
for num in arr:          
    if num % 2 == 0:     
        even.append(num)  

if len(even) > 0:  
    result = sum(even) / len(even)
    print("Среднее арифметическое чётных чисел:", result)
else:                   
   print("В массиве нет четных чисел")
print("Количество чисел, делящихся на 3:", count)
