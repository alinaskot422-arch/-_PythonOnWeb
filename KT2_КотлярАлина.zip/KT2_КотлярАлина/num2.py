import random 
rows = int(input("Введите количество строк: "))      
colums = int(input("Введите количество столбцов: "))   
arr = [] 

for i in range(rows):         
    row = []         
    for j in range(colums):  
        num = random.randint(-20, 20) 
        row.append(num)        
    arr.append(row)          
print("Двумерный массив:")

for row in arr:               
    print(row)                 

min = arr[0][0]           
for i in range(rows):        
    for j in range(colums):
        if arr[i][j] < min:  
            min = arr[i][j]  
print("Минимальный элемент:", min)

if rows >= 2:                  
    print("Вторая строка:", arr[1]) 
else:
    print("В массиве меньше двух строк")

colum = []                
for i in range(rows):    
    colum.append(arr[i][0]) 
print("Первый столбец:", colum)
