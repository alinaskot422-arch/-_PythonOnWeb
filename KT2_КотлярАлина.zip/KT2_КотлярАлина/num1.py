arr = list(range(1, 11))
print(arr)
arr.reverse()  
print("Перевёрнутый массив:", arr)